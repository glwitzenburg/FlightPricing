package com.company;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {


    //static variables
    static Map<String, Integer> monthDayCounter = new HashMap<String, Integer>();
    static String keyValue = "SIGNUP FOR KEY"; //https://rapidapi.com/search/skyscanner
    static String key = "X-RapidAPI-Key";
    public static final String ACCOUNT_SID = "SIGN UP ON TWILIO";
    public static final String AUTH_TOKEN = "SIGN UP ON TWILIO";
    public static Scanner sc = new Scanner(System.in);
    static Date returnDate;
    static String dateToReturn;
    static Double minimumPrice;
    static String startingLocation;
    static String endingLocation;
    static int carrierId;
    static String carrierName;
    static String URL = "https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/browsequotes/v1.0/US/USD/en-US/DSM-sky/HNL-sky/";
    public static HttpGet httpGet;
    public static CloseableHttpClient httpclient = HttpClients.createDefault();

    public static void main(String[] args) throws IOException, ParseException, java.text.ParseException {
        //getForPricingInformation();
        runningPriceFunction();
    }

    public static String getForPricingInformation() throws IOException {
        CloseableHttpResponse response1 = httpclient.execute(httpGet);
        String responseToBeReturned = org.apache.http.util.EntityUtils.toString(response1.getEntity());
        response1.close();
        return responseToBeReturned;
    }

    public static void runningPriceFunction() throws java.text.ParseException, IOException, ParseException {
        //putting all of the months/day counts into a hash
        monthDayCounter.put("01",31);
        monthDayCounter.put("02",28);
        monthDayCounter.put("03",31);
        monthDayCounter.put("04",30);
        monthDayCounter.put("05",31);
        monthDayCounter.put("06",30);
        monthDayCounter.put("07",31);
        monthDayCounter.put("08",31);
        monthDayCounter.put("09",30);
        monthDayCounter.put("10",31);
        monthDayCounter.put("11",30);
        monthDayCounter.put("12",31);
        //
        int year = 2019;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date todayDate = new Date();
        String dateInStringFormat = formatter.format(todayDate);
        dateToReturn = dateInStringFormat;
        int currentDateCounter = Integer.valueOf(dateInStringFormat.substring(dateInStringFormat.length()-2), dateInStringFormat.length()); //DD part
        int monthCounter = 1;
        int whatMonthIsItCounter = Integer.valueOf(dateInStringFormat.substring(5,7));
        //increment 12 times, for the 12 different months
        for(int i = Integer.valueOf(dateInStringFormat.substring(5,7)); monthCounter <= 12 ; i++ ){

            //increment the amount of days in a month

            while(currentDateCounter < monthDayCounter.get(dateToReturn.substring(5,7))){
                dateToReturn = String.valueOf(year)+"-" +String.valueOf(whatMonthIsItCounter)+"-"+String.valueOf(currentDateCounter);
                returnDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateToReturn);
                dateToReturn = formatter.format(returnDate);
                httpGet = new HttpGet(URL+dateToReturn);
                httpGet.setHeader(key,keyValue);
                CloseableHttpResponse response1 = httpclient.execute(httpGet);
                String responseToBeReturned = org.apache.http.util.EntityUtils.toString(response1.getEntity());
                String cool = jsonForPriceParser(responseToBeReturned);
                if(!cool.equals("")){
                    //twilioText(dateToReturn + " " + cool); --DO NOT TURN ON UNLESS TESTED
                    System.out.println(dateToReturn + " " + cool);
                }
                response1.close();
                currentDateCounter++;
            }
            currentDateCounter = 1; //resetting to the first day of the month
            monthCounter++;
            //same year
            if(whatMonthIsItCounter <13){
                whatMonthIsItCounter++;
                //new year
            }
            else{
                year = 2020;
                whatMonthIsItCounter=1;
            }
        }
    }

    public static String jsonForPriceParser(String inputFromGetForPricingInformation) throws ParseException {
        String toReturn = "";
        Map<Long, String> carrierIdHolder = new HashMap<Long, String>();
        Object obj = new JSONParser().parse(inputFromGetForPricingInformation);
        JSONObject jo = (JSONObject)obj;
        JSONArray rayOfCarriers = (JSONArray) jo.get("Carriers");
        int counter = 0;
        while(counter < rayOfCarriers.size()){
            JSONObject carrierObj = (JSONObject) rayOfCarriers.get(counter);
            carrierIdHolder.put((Long) carrierObj.get("CarrierId"), (String) carrierObj.get("Name"));
            counter++;
        }
        counter = 0;
        JSONArray rayOfQuotes = (JSONArray) jo.get("Quotes");

        while(counter < rayOfQuotes.size()) {

            JSONObject quotesObj = (JSONObject) rayOfQuotes.get(counter);
            Double minimumPrice = (Double) quotesObj.get("MinPrice");
            JSONObject objForCarrier = (JSONObject) quotesObj.get("OutboundLeg");
            JSONArray getCarrierIdInfo = (JSONArray) objForCarrier.get("CarrierIds");
            int counterForCarriers = 0;
            while(counterForCarriers < getCarrierIdInfo.size()){
                toReturn = carrierIdHolder.get(getCarrierIdInfo.get(counterForCarriers)) + " $" + minimumPrice;
                counterForCarriers++;
            }
            counter++;
        }
        return toReturn;
    }

    public static void twilioText(String input){
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        Message message = Message.creator(new PhoneNumber("YOUR NUMBER HERE"),
                new PhoneNumber("SIGN UP ON TWILIO"),
                input).create();

        System.out.println(message.getSid());
    }
}
